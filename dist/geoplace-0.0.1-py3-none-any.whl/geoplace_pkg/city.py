def cityName(name):
    print("Hello ", name)